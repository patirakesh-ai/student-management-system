
Student Management System Assignment

Features:
- Student Admission
- Multiple Addresses (One-To-Many)
- Course Management
- Course Assignment (Many-To-Many)
- Search Student By Name
- Get Students By Course
- Update Student Profile
- Leave Course
- Swagger
- Validation
- Exception Handling
